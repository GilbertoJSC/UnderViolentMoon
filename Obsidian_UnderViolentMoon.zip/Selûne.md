#divindade

Uma das coisa que encontramos foi um [[Lago Congelado]], que tinha o selo de Selûne;

Temos também os braceletes que foram colocados nos convidados licantropos no retiro de inverno em [[Harstvale]] que fica no extremo norte de Sword Coast.

Era a deusa maior durante o império [[Netherill]].
