um dragão de bronze, chamado [[Glister]], convertido em [[Dragão das Sombras]] por [[Vanrak Moonstar]], que é obviamente faz parte dos nossos #Inimigos .

