Um clérigo de [[Selûne]] que faz parte dos #patinhas_peludas .
