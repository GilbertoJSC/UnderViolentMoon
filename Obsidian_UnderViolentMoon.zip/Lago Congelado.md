#local 
Onde ocorreu nosso primeiro encontro com os orcs membros do grupo mercenário. [[Desespero Rubro]].
Nesse lago encontramos uma porta selada com o marca de [[Selûne]], que aparentemente contem [[Relíquias]] da época do império [[Netherill]].
