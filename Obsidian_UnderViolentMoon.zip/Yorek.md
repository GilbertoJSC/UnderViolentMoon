Um ranger de [[Selûne]] que faz parte dos #patinhas_peludas .
Seu companheiro [[Pantamileon]] foi morto pelos membros da [[Desespero Rubro]].