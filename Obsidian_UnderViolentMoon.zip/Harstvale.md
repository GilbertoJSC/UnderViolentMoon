#local 
[[Lago Congelado]]
[[Ice Spires]]
[[Relíquias]]
[[Conclave Esmeralda]]
[[Taumarik]]
