Atual líder do [[Culto do Dragão]] e tem como aliado [[Vanrak Moonstar]], logo, está do lado dos nossos #Inimigos .

