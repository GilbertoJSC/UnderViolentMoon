#local 
Uma importante cidade na [[Sword Coast]].
Várias descidas para [[Undermountain]] ficam nela.
Residência da desgraçada [[Casa Moonstar]].
