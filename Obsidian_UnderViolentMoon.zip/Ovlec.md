#patinhas_peludas
