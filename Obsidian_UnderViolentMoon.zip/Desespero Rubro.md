Clã de mercenários Orcs, contratados pelo [[Culto do Dragão]] para roubar as [[Relíquias]] dos [[Utghardt]] no norte, nos [[Montes Ancestrais]].
Já travamos diversas batalhas contra eles, sendo nosso primeiros #Inimigos , inclusive derrotamos um membro importante de quem ~~roubamos~~ obtivemos como espólio a [[Winter Fang]].
Agora eles estão nos perseguindo em [[Undermountain]].