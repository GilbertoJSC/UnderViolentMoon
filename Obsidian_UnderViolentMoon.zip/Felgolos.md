#aliados 
Um dragão de bronze, com uma curiosa magia de se comunicar através de moldura de quadros.
Colocou um espião no [[Culto do Dragão]], o [[Bronco]].
Interviu na reunião onde [[Taumarik]] passou nossa missão, porque acredita que [[Vanrak Moonstar]] adiquiriu o conhecimento para transformar uma [[Dragão Metálico]] num [[Dragão das Sombras]].
Também é conhecido como *The Flying Misfortune*.
