#Inimigos 
[[Selûne]]
[[Cultistas de Shar]]
