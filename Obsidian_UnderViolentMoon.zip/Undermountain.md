#local 
[[SkullPort]]
[[Halaster Blackcloak]]
[[Guilda de Xanathar]]
[[Bazar Goblin]]

