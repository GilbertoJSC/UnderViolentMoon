Atual rei do [[Harstvale]] que deve ser um dos nossos #aliados .
