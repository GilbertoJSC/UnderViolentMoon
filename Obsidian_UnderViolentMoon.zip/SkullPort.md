#local 
Devemos encontrar um membro dos [[Arpistas]], que irá nos ajudar a encontrar [[Vanrak Moonstar]], [[Severin Siljarin]] e outros membros do [[Culto do Dragão]].
