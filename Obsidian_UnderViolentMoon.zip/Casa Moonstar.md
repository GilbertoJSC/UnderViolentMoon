#aliados

Tentou Capturar [[Vanrak Moonstar]] com a ajuda de um dragão de bronze chamado [[Glister]], que foi transformado num [[Dragão das Sombras]], por ele.
Casa [[Drows]] que já fez parte da nobreza de [[Waterdeep]] mas que hoje se encontra em desgraça devido as ações de Vanrak.

