![[Pasted image 20240529110013.png]]
#Inimigos 
Uma das muitas casas [[Drows]] e da qual nos conseguimos alguns espólios de batalha e com algum tipo de lotação em [[SkullPort]].


