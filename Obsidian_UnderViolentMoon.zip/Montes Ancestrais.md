#local 
Lar dos [[Utghardt]] e local de onde o [[Culto do Dragão]] e o [[Desespero Rubro]] roubaram algumas [[Relíquias]].