#Inimigos 
Uma guilda de ladrões residente em [[Undermountain]] que por alguma razão não gosta da gente.