[[Culto do Dragão]]

Uma delas nós conseguimos salvar, a estatua de um Basilisco que hoje está em posse do [[Ovlec]].
