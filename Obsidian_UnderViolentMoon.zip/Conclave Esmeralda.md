#aliados 
Também está combatendo o [[Culto do Dragão]].