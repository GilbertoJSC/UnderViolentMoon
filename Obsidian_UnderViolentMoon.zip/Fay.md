#aliados 
Uma fada aliada de [[Dorgot]], que foi capturada pelo [[Desespero Rubro]].