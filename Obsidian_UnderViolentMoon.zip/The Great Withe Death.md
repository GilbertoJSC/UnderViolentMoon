#Inimigos 
O Dragão branco responsável pela destruição em [[Ice Spires]] e está junto com o [[Culto do Dragão]].
