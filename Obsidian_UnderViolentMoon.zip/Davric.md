Um guerreiro de [[Selûne]] que faz parte dos #patinhas_peludas .
Está em posse da [[Winter Fang]]
