Licantropos seguidores de [[Shar]] liderados por [[Vanrak Moonstar]], que obviamente são nosso #Inimigos pois estão junto ao [[Culto do Dragão]].
