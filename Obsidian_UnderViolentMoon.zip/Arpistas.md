São um dos nossos poucos #aliados 
[[SkullPort]]
