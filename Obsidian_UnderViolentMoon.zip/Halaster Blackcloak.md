Conhecido também como *Mad Mage*, responsável pela "criação" de [[Undermountain]].
