Tribos bárbaras do Norte, uma delas conhecida como [[Lobos Cinzentos]].
Eram responsáveis pela guarda de algumas [[Relíquias]].
