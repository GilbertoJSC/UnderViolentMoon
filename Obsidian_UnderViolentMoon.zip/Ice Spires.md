#local 
[[Silverymoon]]
O dragão branco que nos atacou se chamava [[The Great Withe Death]].

[[Desespero Rubro]]


