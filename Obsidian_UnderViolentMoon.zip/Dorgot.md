Outro guerreiro de [[Selûne]] que faz parte dos #patinhas_peludas .
Tem como aliado uma fada chamada [[Fay]], que foi apriosionada pelo [[Desespero Rubro]]