#Inimigos

Devoto de [[Shar]].
Afiliado ao [[Culto do Dragão]].
Também conhecido como *Dark Ranger*.
Sua origem remonta uma casa nobre de [[Waterdeep]], a [[Casa Moonstar]] que agora está em desgraça, por causa de suas ações.
Segundo informações se encontra refugiado em [[SkullPort]].

