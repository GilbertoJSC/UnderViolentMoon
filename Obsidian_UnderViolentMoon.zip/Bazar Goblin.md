Um #local em [[Undermountain]] com um mercado, inclusive de escravos, capturados por [[Drows]], que agora está no roll de nossos #Inimigos .
